package choreographers.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import choreographers.entity.Choreographers;


public interface ChoreographersRepo extends JpaRepository<Choreographers, Integer> {
	
	public List<Choreographers> findByCid(Integer Custid);

}
