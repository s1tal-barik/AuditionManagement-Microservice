package choreographers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuditionChoreographersApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuditionChoreographersApplication.class, args);
	}

}
