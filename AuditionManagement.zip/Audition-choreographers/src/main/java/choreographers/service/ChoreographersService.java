package choreographers.service;

import java.util.List;

import choreographers.entity.Choreographers;

public interface ChoreographersService {
	
	public List<Choreographers> getAllChoreos();
	public List<Choreographers> getChoreoBycId(Integer cid);

}
