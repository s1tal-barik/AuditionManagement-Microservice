package choreographers.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import choreographers.entity.Choreographers;
import choreographers.repo.ChoreographersRepo;


@Service
public class ChoreographersServiceImpl implements ChoreographersService{

	@Autowired
	ChoreographersRepo choreographersRepo;
	


	@Override
	public List<Choreographers> getAllChoreos() {
		
		return choreographersRepo.findAll();
	}


	@Override
	public List<Choreographers> getChoreoBycId(Integer cid) {
		// TODO Auto-generated method stub
		return choreographersRepo.findByCid(cid);
	}

}
