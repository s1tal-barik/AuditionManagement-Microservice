package choreographers.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "choreographersdetails")
public class Choreographers {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer chid;
	private int cid;
	private String ChName;
	private String ChAge;
	
	public Choreographers() {
		
		super();
	}

	public Integer getChid() {
		return chid;
	}

	public void setChid(Integer chid) {
		this.chid = chid;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getChName() {
		return ChName;
	}

	public void setChName(String chName) {
		ChName = chName;
	}

	public String getChAge() {
		return ChAge;
	}

	public void setChAge(String chAge) {
		ChAge = chAge;
	}

	public Choreographers(Integer chid, int cid, String chName, String chAge) {
		super();
		this.chid = chid;
		this.cid = cid;
		ChName = chName;
		ChAge = chAge;
	}
	
	
	
	
	
	

	
}
