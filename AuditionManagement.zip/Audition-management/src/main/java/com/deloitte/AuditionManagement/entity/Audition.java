package com.deloitte.AuditionManagement.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "contestantsdetails")
public class Audition {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cid;
	private String Cname;
	private String Cage;
		
	public Audition() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Audition(int cid, String cname, String cage) {
		super();
		this.cid = cid;
		Cname = cname;
		Cage = cage;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCname() {
		return Cname;
	}

	public void setCname(String cname) {
		Cname = cname;
	}

	public String getCage() {
		return Cage;
	}

	public void setCage(String cage) {
		Cage = cage;
	}
	
}