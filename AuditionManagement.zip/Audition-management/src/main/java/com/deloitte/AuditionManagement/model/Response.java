package com.deloitte.AuditionManagement.model;

import java.util.List;

import com.deloitte.AuditionManagement.entity.Audition;

public class Response
{
	private List<Audition> contestantResponse;
	private List<Choreographer> choreographerResponse;
	public Response() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Response(List<Audition> contestantResponse, List<Choreographer> choreographerResponse) {
		super();
		this.contestantResponse = contestantResponse;
		this.choreographerResponse = choreographerResponse;
	}
	public List<Audition> getContestantResponse() {
		return contestantResponse;
	}
	public void setContestantResponse(List<Audition> contestantResponse) {
		this.contestantResponse = contestantResponse;
	}
	public List<Choreographer> getChoreographerResponse() {
		return choreographerResponse;
	}
	public void setChoreographerResponse(List<Choreographer> choreographerResponse) {
		this.choreographerResponse = choreographerResponse;
	}
	
	
	
}
