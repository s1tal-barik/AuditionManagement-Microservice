package com.deloitte.AuditionManagement.model;

public class Choreographer
{
	private Integer chid;
	private int cid;
	private String ChName;
	private String ChAge;
	public Choreographer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Choreographer(Integer chid, int cid, String chName, String chAge) {
		super();
		this.chid = chid;
		this.cid = cid;
		ChName = chName;
		ChAge = chAge;
	}
	public Integer getChid() {
		return chid;
	}
	public void setChid(Integer chid) {
		this.chid = chid;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getChName() {
		return ChName;
	}
	public void setChName(String chName) {
		ChName = chName;
	}
	public String getChAge() {
		return ChAge;
	}
	public void setChAge(String chAge) {
		ChAge = chAge;
	}
	
	
}
