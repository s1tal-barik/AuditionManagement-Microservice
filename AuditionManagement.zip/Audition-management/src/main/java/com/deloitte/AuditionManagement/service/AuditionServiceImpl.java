package com.deloitte.AuditionManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.AuditionManagement.entity.Audition;
import com.deloitte.AuditionManagement.repo.AuditionRepo;


@Service
public class AuditionServiceImpl implements AuditionService
{
	@Autowired
	private AuditionRepo auditionrepo;

	@Override
	public List<Audition> getAllAuditions() {
		
		return auditionrepo.findAll();
	}

	@Override
	public List<Audition> getAudition(Integer id) {
		// TODO Auto-generated method stub
		return auditionrepo.findByCid(id);
	}

}
