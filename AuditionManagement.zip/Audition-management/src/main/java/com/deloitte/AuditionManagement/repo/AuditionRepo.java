package com.deloitte.AuditionManagement.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deloitte.AuditionManagement.entity.Audition;



public interface AuditionRepo extends JpaRepository<Audition, Integer>
{
	public List<Audition> findByCid(Integer contestant_id);
}
