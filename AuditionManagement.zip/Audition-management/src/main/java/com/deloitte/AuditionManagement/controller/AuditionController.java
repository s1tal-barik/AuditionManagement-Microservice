package com.deloitte.AuditionManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.deloitte.AuditionManagement.entity.Audition;
import com.deloitte.AuditionManagement.model.Choreographer;
import com.deloitte.AuditionManagement.model.Response;
import com.deloitte.AuditionManagement.service.AuditionService;


@RestController
@RequestMapping("/audition")
public class AuditionController {
	
	@Autowired
	private AuditionService auditionService;
	
	@Autowired
	private RestTemplate resttemp;
	
	@GetMapping("/getallauditions")
	public ResponseEntity<List<Audition>> getAllparticipants()
	{
		List<Audition> participants = auditionService.getAllAuditions();
		return new ResponseEntity<List<Audition>>(participants, HttpStatus.OK);
	}
	
	@GetMapping("/getaudition/{cid}")
	public ResponseEntity<Response> getparticipantById(@PathVariable("cid") Integer id)
	{
		List<Audition> participant = auditionService.getAudition(id);
		List<Choreographer> choreographer = resttemp.getForObject("http://localhost:8089/Choreographers/getChoreographer/"+id, List.class);
		Response res = new Response(participant, choreographer);
		return new ResponseEntity<Response>(res, HttpStatus.OK);
	}
	
}