package com.deloitte.AuditionManagement.service;

import java.util.List;

import com.deloitte.AuditionManagement.entity.Audition;


public interface AuditionService
{
	public List<Audition> getAllAuditions();
	public List<Audition> getAudition(Integer id);
}
