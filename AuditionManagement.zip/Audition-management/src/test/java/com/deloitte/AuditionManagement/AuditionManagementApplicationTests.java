package com.deloitte.AuditionManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuditionManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
